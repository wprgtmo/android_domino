package cu.nat.wenisimo.appdomino.models;

import java.util.ArrayList;

public class EventoRespuesta {
    private ArrayList<Evento> eventos;

    public ArrayList<Evento> getEventos() {
        return eventos;
    }

    public void setEventos(ArrayList<Evento> eventos) {
        this.eventos = eventos;
    }
}
