package cu.nat.wenisimo.appdomino.models;

public class DataRespuesta {
    Data data;

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }
}
