package cu.nat.wenisimo.appdomino.models;


public class ParejaRespuesta {

    private Pareja pareja;

    public Pareja getPareja() {
        return pareja;
    }

    public void setPareja(Pareja pareja) {
        this.pareja = pareja;
    }
}

