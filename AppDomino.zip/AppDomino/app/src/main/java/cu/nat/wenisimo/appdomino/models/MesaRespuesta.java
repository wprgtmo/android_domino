package cu.nat.wenisimo.appdomino.models;


import java.util.ArrayList;

public class MesaRespuesta {

    private ArrayList<Mesa> mesas;

    public ArrayList<Mesa> getMesas() {
        return mesas;
    }

    public void setMesas(ArrayList<Mesa> mesas) {
        this.mesas = mesas;
    }
}
