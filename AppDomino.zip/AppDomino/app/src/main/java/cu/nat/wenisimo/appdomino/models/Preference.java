package cu.nat.wenisimo.appdomino.models;

import android.content.SharedPreferences;

public class Preference {
    public SharedPreferences datos;

    public Preference() {
    }
}
