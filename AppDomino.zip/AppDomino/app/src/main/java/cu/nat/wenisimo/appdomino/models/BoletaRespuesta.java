package cu.nat.wenisimo.appdomino.models;

public class BoletaRespuesta {
    private Boleta boleta;

    public Boleta getBoleta() {
        return boleta;
    }

    public void setBoleta(Boleta boleta) {
        this.boleta = boleta;
    }
}
