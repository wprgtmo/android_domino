package cu.nat.wenisimo.appdomino.models;

import java.util.ArrayList;

public class ParejasMesaRespuesta {
    private ArrayList<ParejasMesa> parejasMesa;

    public ArrayList<ParejasMesa> getParejasMesa() {
        return parejasMesa;
    }

    public void setParejasMesa(ArrayList<ParejasMesa> parejasMesa) {
        this.parejasMesa = parejasMesa;
    }
}
