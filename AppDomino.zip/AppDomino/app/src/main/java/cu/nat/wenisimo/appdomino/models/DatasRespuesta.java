package cu.nat.wenisimo.appdomino.models;

import java.util.ArrayList;

public class DatasRespuesta {

    private ArrayList<Data> data;

    public ArrayList<Data> getData() {
        return data;
    }

    public void setData(ArrayList<Data> data) {
        this.data = data;
    }

}
