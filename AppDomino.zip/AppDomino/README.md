# android_domino
Interfaz nativa para Android del cliente del control de los eventos de domino
Esta interfaz implementa un reloj para el control del tiempo de las parejas 
